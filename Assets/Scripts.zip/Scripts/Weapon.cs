using UnityEngine;
 
/// <summary>
/// 무기 데이터 정의 (ScriptableObject)
/// Assets 우클릭 → Create → GunSystem → Weapon 으로 에셋 생성
/// </summary>
[CreateAssetMenu(menuName = "GunSystem/Weapon", fileName = "New Weapon")]
public class Weapon : ScriptableObject
{
    [Header("기본 정보")]
    public string  weaponName  = "Pistol";
    public Sprite  icon;                        // 덱 UI 아이콘
    public WeaponType type     = WeaponType.Pistol;
 
    [Header("발사")]
    public FireMode fireMode   = FireMode.SemiAuto;
    public float    fireRate   = 0.25f;         // 발사 간격 (초)
    public int      bulletsPerShot = 1;         // 산탄 수
    public float    spreadAngle    = 0f;        // 산탄 퍼짐 각도
 
    [Header("탄약")]
    public int   magazineSize  = 12;
    public float reloadTime    = 1.4f;
    public bool  infiniteAmmo  = false;
 
    [Header("데미지 / 물리")]
    public float damage        = 25f;
    public float bulletSpeed   = 40f;
    public float bulletRange   = 50f;           // 최대 사거리
    public float knockback     = 2f;
 
    [Header("반동")]
    public float recoilUp      = 1.5f;          // 카메라 위로 올라가는 양
    public float recoilSide    = 0.3f;
 
    [Header("덱 빌딩")]
    [Tooltip("덱에 추가될 때 표시될 설명")]
    [TextArea(2, 4)]
    public string description  = "";
    public WeaponRarity rarity = WeaponRarity.Common;
}
 
public enum WeaponType
{
    Pistol,
    Shotgun,
    SMG,
    Rifle,
    Sniper,
    RocketLauncher,
    Holy        // 게임 고유 신성 무기
}
 
public enum FireMode
{
    SemiAuto,   // 클릭당 1발
    FullAuto,   // 버튼 홀드
    Burst       // 3점사
}
 
public enum WeaponRarity
{
    Common,
    Uncommon,
    Rare,
    Epic,
    Legendary
}