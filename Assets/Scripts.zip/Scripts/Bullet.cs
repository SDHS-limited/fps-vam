using UnityEngine;
 
/// <summary>
/// 총알 이동 및 충돌 처리
/// Bullet Prefab에 부착. Rigidbody(Kinematic) + SphereCollider(Trigger) 필요
/// </summary>
public class Bullet : MonoBehaviour
{
    // WeaponController가 Spawn 후 Init() 호출로 세팅
    float damage;
    float speed;
    float range;
    float knockback;
    float traveledDist = 0f;
 
    Vector3 direction;
 
    public void Init(Vector3 dir, float dmg, float spd, float rng, float kb)
    {
        direction = dir.normalized;
        damage    = dmg;
        speed     = spd;
        range     = rng;
        knockback = kb;
    }
 
    void Update()
    {
        float step = speed * Time.deltaTime;
        transform.position += direction * step;
        traveledDist       += step;
 
        if (traveledDist >= range)
            Destroy(gameObject);
    }
 
    void OnTriggerEnter(Collider other)
    {
        // 자기 자신(Player) 무시
        if (other.CompareTag("Player")) return;
 
        // 데미지
        var health = other.GetComponent<IDamageable>();
        health?.TakeDamage(damage);
 
        // 넉백
        var enemyRb = other.GetComponent<Rigidbody>();
        if (enemyRb != null)
            enemyRb.AddForce(direction * knockback, ForceMode.Impulse);
 
        // 히트 이펙트 (있으면)
        var fx = other.GetComponent<IHitEffect>();
        fx?.OnHit(transform.position, direction);
 
        Destroy(gameObject);
    }
}
 
// ── 인터페이스 ────────────────────────────────────────────────────
 
public interface IDamageable
{
    void TakeDamage(float amount);
}
 
public interface IHitEffect
{
    void OnHit(Vector3 position, Vector3 direction);
}