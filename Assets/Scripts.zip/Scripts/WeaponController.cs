using UnityEngine;
 
/// <summary>
/// 무기 장착 / 교체 / 조준 / 반동 카메라 적용
/// Player GameObject에 부착
/// ShootingSystem과 WeaponDeck을 연결하는 중간 컨트롤러
/// </summary>
[RequireComponent(typeof(ShootingSystem))]
public class WeaponController : MonoBehaviour
{
    [Header("레퍼런스")]
    public Transform   cameraTransform;     // Player 자식 Camera
    public Transform   gunPivot;            // 카메라 자식 GunPivot (총 모델 붙이는 곳)
 
    [Header("반동 회복 속도")]
    public float recoilRecoverSpeed = 6f;
 
    // ── 내부 ──────────────────────────────────────────────────────
 
    ShootingSystem shooting;
    WeaponDeck     deck;
 
    Weapon         equippedWeapon;
 
    // FPS 카메라 피치 (GravityPlayerController의 pitch와 동기화 필요)
    // → GravityPlayerController가 노출하는 pitch 값을 읽어서 반동 더함
    GravityPlayerController playerCtrl;
 
    void Awake()
    {
        shooting   = GetComponent<ShootingSystem>();
        deck       = WeaponDeck.Instance
                     ?? FindFirstObjectByType<WeaponDeck>();
        playerCtrl = GetComponent<GravityPlayerController>();
 
        if (cameraTransform == null)
        {
            var cam = GetComponentInChildren<Camera>();
            if (cam) cameraTransform = cam.transform;
        }
 
        // ShootingSystem에 카메라 연결
        shooting.cameraTransform = cameraTransform;
    }
 
    void Start()
    {
        if (deck == null) return;
 
        // 덱 이벤트 구독
        deck.onSlotChanged += _ => RefreshWeapon();
        deck.onDeckChanged += RefreshWeapon;
 
        RefreshWeapon();
    }
 
    // ── 무기 교체 ─────────────────────────────────────────────────
 
    void RefreshWeapon()
    {
        if (deck == null) return;
        Weapon newWeapon = deck.ActiveWeapon;
        if (newWeapon == equippedWeapon) return;
 
        equippedWeapon = newWeapon;
        shooting.EquipWeapon(equippedWeapon);
    }
 
    // ── Update : 입력 ─────────────────────────────────────────────
 
    void Update()
    {
        if (equippedWeapon == null) return;
 
        HandleFireInput();
        HandleSlotSwitch();
        HandleReload();
    }
 
    void HandleFireInput()
    {
        bool fireInput = equippedWeapon.fireMode == FireMode.FullAuto
                         ? Input.GetMouseButton(0)       // 홀드
                         : Input.GetMouseButtonDown(0);  // 클릭
 
        if (fireInput)
            shooting.TryFire();
    }
 
    void HandleSlotSwitch()
    {
        if (deck == null) return;
 
        // 숫자키 1~4
        for (int i = 0; i < 4; i++)
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
                deck.SetActiveSlot(i);
 
        // 마우스 스크롤
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll > 0f)  deck.PrevSlot();
        if (scroll < 0f)  deck.NextSlot();
    }
 
    void HandleReload()
    {
        if (Input.GetKeyDown(KeyCode.R))
            shooting.TryReload();
    }
 
    // ── LateUpdate : 반동 카메라 적용 ────────────────────────────
 
    void LateUpdate()
    {
        if (cameraTransform == null) return;
 
        Vector2 recoil = shooting.ConsumeRecoil(recoilRecoverSpeed);
        // 카메라 pitch에 반동 추가 (위로 튀는 느낌)
        cameraTransform.localRotation *= Quaternion.Euler(-recoil.x * Time.deltaTime * 60f,
                                                           recoil.y * Time.deltaTime * 60f,
                                                           0f);
    }
}