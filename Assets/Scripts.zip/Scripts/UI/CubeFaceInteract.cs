using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

/// <summary>
/// 플레이어가 큐브 면 UI를 바라볼 때 레이캐스트로 버튼 클릭 처리
///
/// Player GameObject에 부착
/// PhysicsRaycaster 없이 직접 UI 버튼을 월드 스페이스에서 클릭
/// </summary>
public class CubeFaceInteract : MonoBehaviour
{
    [Header("레퍼런스")]
    public Camera playerCamera;
 
    [Header("상호작용 거리")]
    public float interactDistance = 8f;
 
    [Header("상호작용 키")]
    public KeyCode interactKey = KeyCode.E;
 
    // 현재 바라보는 Canvas
    Canvas hoveredCanvas;
    float  dotIndicator = 0f;   // 조준 중 0→1 채우기
 
    void Awake()
    {
        if (!playerCamera)
        {
            var cam = GetComponentInChildren<Camera>();
            if (cam) playerCamera = cam;
        }
 
        // EventSystem 없으면 자동 생성
        if (FindFirstObjectByType<EventSystem>() == null)
        {
            new GameObject("EventSystem").AddComponent<EventSystem>()
                .gameObject.AddComponent<StandaloneInputModule>();
        }
    }
 
    void Update()
    {
        DetectFaceUI();
 
        // E키 또는 좌클릭으로 UI 버튼 클릭
        if (Input.GetKeyDown(interactKey) || Input.GetMouseButtonDown(0))
            TryClickUI();
    }
 
    // ── 면 UI 감지 ────────────────────────────────────────────────
 
    void DetectFaceUI()
    {
        Ray ray = new Ray(playerCamera.transform.position,
                          playerCamera.transform.forward);
 
        if (!Physics.Raycast(ray, out RaycastHit hit, interactDistance))
        {
            hoveredCanvas = null;
            return;
        }
 
        // 맞은 오브젝트의 부모 계층에서 Canvas 탐색
        Canvas c = hit.collider.GetComponentInParent<Canvas>();
        if (c == null)
        {
            // 큐브 자체를 맞혔을 때 → 바라보는 면의 Canvas 찾기
            CubeFaceUI cubeUI = hit.collider.GetComponentInParent<CubeFaceUI>();
            if (cubeUI != null)
            {
                // 가장 가까운 Canvas 찾기 (법선 방향 기반)
                c = FindClosestFaceCanvas(hit.normal, cubeUI.transform);
            }
        }
        hoveredCanvas = c;
    }
 
    Canvas FindClosestFaceCanvas(Vector3 hitNormal, Transform cubeTransform)
    {
        Canvas best      = null;
        float  bestDot   = -1f;
 
        foreach (Canvas canvas in cubeTransform.GetComponentsInChildren<Canvas>())
        {
            float d = Vector3.Dot(canvas.transform.forward, -hitNormal);
            if (d > bestDot) { bestDot = d; best = canvas; }
        }
        return best;
    }
 
    // ── UI 클릭 ───────────────────────────────────────────────────
 
    void TryClickUI()
    {
        if (hoveredCanvas == null) return;
 
        Ray ray = new Ray(playerCamera.transform.position,
                          playerCamera.transform.forward);
 
        // Canvas 평면과 교점 계산
        Plane plane = new Plane(hoveredCanvas.transform.forward,
                                hoveredCanvas.transform.position);
        if (!plane.Raycast(ray, out float enter)) return;
 
        Vector3 worldHit = ray.GetPoint(enter);
 
        // 월드 좌표 → Canvas 로컬 좌표로 변환
        RectTransform canvasRT = hoveredCanvas.GetComponent<RectTransform>();
        if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                canvasRT,
                playerCamera.WorldToScreenPoint(worldHit),
                playerCamera,
                out Vector2 localPoint))
            return;
 
        // 해당 위치의 버튼 탐색
        PointerEventData ped = new PointerEventData(EventSystem.current)
        {
            position = playerCamera.WorldToScreenPoint(worldHit)
        };
 
        var results = new System.Collections.Generic.List<RaycastResult>();
        // GraphicRaycaster로 클릭 처리
        hoveredCanvas.GetComponent<GraphicRaycaster>()
                     ?.Raycast(ped, results);
 
        foreach (var result in results)
        {
            var btn = result.gameObject.GetComponent<UnityEngine.UI.Button>();
            if (btn != null)
            {
                btn.onClick.Invoke();
                break;
            }
        }
    }
 
    // ── HUD : 상호작용 안내 ───────────────────────────────────────
 
    void OnGUI()
    {
        if (hoveredCanvas == null) return;
 
        float cx = Screen.width  * 0.5f;
        float cy = Screen.height * 0.5f;
        float r  = 22f;
 
        // 바라보는 면 이름 표시
        var style = new GUIStyle(GUI.skin.label)
        {
            fontSize  = 14,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter,
            normal    = { textColor = new Color(0.4f, 0.9f, 1f) }
        };
 
        GUI.Label(new Rect(cx - 120, cy + r + 10, 240, 24),
                  $"[E] 또는 클릭으로 상호작용", style);
    }
}
 