using UnityEngine;
using UnityEngine.UI;
using TMPro;
using System.Collections;
using System.Collections.Generic;
 
/// <summary>
/// 큐브 4면에 World Space UI를 자동 생성
///
/// [셋업]
/// 1. 큐브 GameObject에 이 스크립트 부착
/// 2. Inspector에서 weaponDatabase에 Weapon 에셋 등록
/// 3. WeaponDeck 싱글턴이 씬에 있어야 함
///
/// [면 배치]
///  앞면(+Z) : 웨이브 시작 패널
///  오른쪽(+X) : 덱 선택 슬롯 A
///  뒷면(-Z) : 덱 선택 슬롯 B
///  왼쪽(-X) : 덱 선택 슬롯 C
/// </summary>
public class CubeFaceUI : MonoBehaviour
{
    [Header("큐브 크기 (Scale과 맞춰서 입력)")]
    public float cubeSize = 1f;
 
    [Header("무기 데이터베이스 (덱 선택에 표시할 무기들)")]
    public List<Weapon> weaponDatabase = new();
 
    [Header("웨이브 설정")]
    public int totalWaves = 5;
 
    // ── 내부 상태 ─────────────────────────────────────────────────
    int  currentWave   = 0;
    bool waveRunning   = false;
 
    // 각 덱 슬롯이 현재 선택 중인 무기 인덱스
    int[] slotSelection = new int[3] { 0, 1, 2 };
 
    // 생성된 패널 루트
    GameObject[] panels = new GameObject[4];
 
    // UI 텍스트 참조 (업데이트용)
    TextMeshProUGUI waveStatusText;
    TextMeshProUGUI waveButtonText;
    Image           waveButtonBG;
 
    // 덱 패널 참조
    DeckSlotPanel[] deckPanels = new DeckSlotPanel[3];
 
    // ── 면 정의 ───────────────────────────────────────────────────
    struct FaceDef
    {
        public Vector3 normal;   // 면이 향하는 방향
        public Vector3 up;       // 패널의 위쪽 방향
    }
 
    static readonly FaceDef[] Faces = new FaceDef[]
    {
        new FaceDef { normal = Vector3.forward,  up = Vector3.up },  // 앞: 웨이브
        new FaceDef { normal = Vector3.right,    up = Vector3.up },  // 오른쪽: 덱A
        new FaceDef { normal = Vector3.back,     up = Vector3.up },  // 뒤: 덱B
        new FaceDef { normal = Vector3.left,     up = Vector3.up },  // 왼쪽: 덱C
    };
 
    // ── 초기화 ────────────────────────────────────────────────────
 
    void Start()
    {
        // 무기 DB 보정: 비어 있으면 최소 3개 슬롯용 null 채우기
        while (weaponDatabase.Count < 3) weaponDatabase.Add(null);
 
        BuildAllFaces();
    }
 
    // ── 전체 면 생성 ──────────────────────────────────────────────
 
    void BuildAllFaces()
    {
        for (int i = 0; i < 4; i++)
        {
            GameObject panel = CreateFaceCanvas(i);
            panels[i] = panel;
 
            if (i == 0) BuildWavePanel(panel);
            else        BuildDeckPanel(panel, i - 1);
        }
    }
 
    // ── World Space Canvas 생성 (공통) ────────────────────────────
 
    GameObject CreateFaceCanvas(int faceIndex)
    {
        FaceDef face = Faces[faceIndex];
 
        // Canvas 루트
        GameObject go = new GameObject($"FaceCanvas_{faceIndex}");
        go.transform.SetParent(transform);
 
        // 위치: 큐브 면 바로 앞으로 오프셋
        float offset = cubeSize * 0.5f + 0.01f;
        go.transform.localPosition = face.normal * offset;
 
        // 회전: 법선 방향을 바라보게
        go.transform.rotation = Quaternion.LookRotation(
            transform.TransformDirection(face.normal),
            transform.TransformDirection(face.up)
        );
 
        // Canvas 컴포넌트
        Canvas canvas = go.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
 
        CanvasScaler scaler = go.AddComponent<CanvasScaler>();
        scaler.dynamicPixelsPerUnit = 100f;
 
        go.AddComponent<GraphicRaycaster>();
 
        // RectTransform 크기 = 큐브 면 크기
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(cubeSize * 100f, cubeSize * 100f);
        rt.localScale = Vector3.one * 0.01f;
 
        return go;
    }
 
    // ════════════════════════════════════════════════════════════
    //  앞면 : 웨이브 시작 패널
    // ════════════════════════════════════════════════════════════
 
    void BuildWavePanel(GameObject root)
    {
        RectTransform rt = root.GetComponent<RectTransform>();
        float W = rt.sizeDelta.x, H = rt.sizeDelta.y;
 
        // ── 배경 ──────────────────────────────────────────────────
        Image bg = CreateImage(root, "BG", new Rect(0, 0, W, H),
                               new Color(0.05f, 0.05f, 0.12f, 0.95f));
        bg.GetComponent<RectTransform>().anchoredPosition = Vector2.zero;
 
        // 테두리 (빛나는 라인)
        CreateBorder(root, W, H, new Color(0.3f, 0.6f, 1f, 0.9f), 3f);
 
        // ── 제목 ──────────────────────────────────────────────────
        TextMeshProUGUI title = CreateTMP(root, "Title",
            "WAVE SYSTEM",
            new Vector2(0, H * 0.35f), new Vector2(W * 0.9f, H * 0.15f),
            36, FontStyles.Bold, new Color(0.4f, 0.8f, 1f));
 
        // ── 웨이브 번호 ───────────────────────────────────────────
        waveStatusText = CreateTMP(root, "WaveStatus",
            $"WAVE  {currentWave} / {totalWaves}",
            new Vector2(0, H * 0.1f), new Vector2(W * 0.9f, H * 0.18f),
            48, FontStyles.Bold, Color.white);
 
        // ── 설명 텍스트 ───────────────────────────────────────────
        CreateTMP(root, "Desc",
            "덱을 구성하고\n웨이브를 시작하세요",
            new Vector2(0, -H * 0.1f), new Vector2(W * 0.85f, H * 0.2f),
            18, FontStyles.Normal, new Color(0.7f, 0.7f, 0.8f));
 
        // ── 시작 버튼 ─────────────────────────────────────────────
        GameObject btnGo = new GameObject("StartButton");
        btnGo.transform.SetParent(root.transform, false);
 
        waveButtonBG = btnGo.AddComponent<Image>();
        waveButtonBG.color = new Color(0.2f, 0.55f, 1f, 1f);
 
        RectTransform btnRT = btnGo.GetComponent<RectTransform>();
        btnRT.anchoredPosition = new Vector2(0, -H * 0.32f);
        btnRT.sizeDelta        = new Vector2(W * 0.65f, H * 0.14f);
 
        waveButtonText = CreateTMP(btnGo, "BtnText",
            "START WAVE",
            Vector2.zero, new Vector2(W * 0.65f, H * 0.14f),
            26, FontStyles.Bold, Color.white);
 
        Button btn = btnGo.AddComponent<Button>();
        btn.targetGraphic = waveButtonBG;
 
        // 버튼 색상 전환
        ColorBlock cb = btn.colors;
        cb.normalColor      = new Color(0.2f, 0.55f, 1f);
        cb.highlightedColor = new Color(0.35f, 0.7f, 1f);
        cb.pressedColor     = new Color(0.1f, 0.35f, 0.8f);
        btn.colors = cb;
 
        btn.onClick.AddListener(OnWaveStartClicked);
 
        // ── 아이콘 데코 ───────────────────────────────────────────
        CreateTMP(root, "Icon",
            "⚔",
            new Vector2(0, H * 0.42f), new Vector2(H * 0.12f, H * 0.12f),
            44, FontStyles.Normal, new Color(1f, 0.8f, 0.3f));
    }
 
    void OnWaveStartClicked()
    {
        if (waveRunning) return;
        if (currentWave >= totalWaves)
        {
            // 모든 웨이브 완료
            waveStatusText.text = "ALL WAVES\nCLEARED!";
            waveStatusText.color = new Color(1f, 0.8f, 0.2f);
            waveButtonText.text  = "COMPLETE";
            waveButtonBG.color   = new Color(0.6f, 0.5f, 0.1f);
            return;
        }
 
        currentWave++;
        waveRunning = true;
 
        waveStatusText.text  = $"WAVE  {currentWave} / {totalWaves}";
        waveButtonText.text  = "WAVE IN PROGRESS...";
        waveButtonBG.color   = new Color(0.5f, 0.15f, 0.15f);
 
        // 실제 웨이브 매니저가 있으면 여기서 호출
        // WaveManager.Instance?.StartWave(currentWave);
 
        // 임시: 5초 후 웨이브 종료 시뮬레이션
        StartCoroutine(SimulateWaveEnd());
    }
 
    IEnumerator SimulateWaveEnd()
    {
        yield return new WaitForSeconds(5f);
        waveRunning = false;
 
        if (currentWave >= totalWaves)
        {
            waveStatusText.text = "ALL CLEAR!";
            waveButtonText.text = "VICTORY";
            waveButtonBG.color  = new Color(0.2f, 0.6f, 0.2f);
        }
        else
        {
            waveButtonText.text = "NEXT WAVE";
            waveButtonBG.color  = new Color(0.2f, 0.55f, 1f);
        }
    }
 
    // ════════════════════════════════════════════════════════════
    //  오른쪽/뒤/왼쪽 : 덱 선택 패널
    // ════════════════════════════════════════════════════════════
 
    void BuildDeckPanel(GameObject root, int deckSlotIndex)
    {
        RectTransform rt = root.GetComponent<RectTransform>();
        float W = rt.sizeDelta.x, H = rt.sizeDelta.y;
 
        // 배경
        CreateImage(root, "BG", new Rect(0, 0, W, H),
                    new Color(0.06f, 0.04f, 0.1f, 0.95f));
 
        // 희귀도별 테두리 색
        Color[] rarityColors =
        {
            new Color(0.3f, 1f, 0.3f, 0.9f),   // Slot 0: 초록(Uncommon)
            new Color(0.3f, 0.5f, 1f, 0.9f),   // Slot 1: 파랑(Rare)
            new Color(0.8f, 0.3f, 1f, 0.9f),   // Slot 2: 보라(Epic)
        };
        CreateBorder(root, W, H, rarityColors[deckSlotIndex], 3f);
 
        // 슬롯 라벨
        string[] slotNames = { "SLOT  A", "SLOT  B", "SLOT  C" };
        CreateTMP(root, "SlotLabel",
            slotNames[deckSlotIndex],
            new Vector2(0, H * 0.42f), new Vector2(W * 0.9f, H * 0.1f),
            20, FontStyles.Bold, rarityColors[deckSlotIndex]);
 
        // 무기 이름
        TextMeshProUGUI nameText = CreateTMP(root, "WeaponName",
            GetWeaponName(deckSlotIndex),
            new Vector2(0, H * 0.22f), new Vector2(W * 0.9f, H * 0.15f),
            28, FontStyles.Bold, Color.white);
 
        // 무기 타입
        TextMeshProUGUI typeText = CreateTMP(root, "WeaponType",
            GetWeaponType(deckSlotIndex),
            new Vector2(0, H * 0.08f), new Vector2(W * 0.9f, H * 0.1f),
            16, FontStyles.Normal, new Color(0.7f, 0.7f, 0.85f));
 
        // 스탯 표시
        TextMeshProUGUI statText = CreateTMP(root, "Stats",
            GetWeaponStats(deckSlotIndex),
            new Vector2(0, -H * 0.1f), new Vector2(W * 0.85f, H * 0.25f),
            14, FontStyles.Normal, new Color(0.8f, 0.85f, 0.9f));
        statText.alignment = TextAlignmentOptions.Left;
 
        // 설명
        TextMeshProUGUI descText = CreateTMP(root, "Desc",
            GetWeaponDesc(deckSlotIndex),
            new Vector2(0, -H * 0.27f), new Vector2(W * 0.85f, H * 0.14f),
            12, FontStyles.Italic, new Color(0.55f, 0.55f, 0.65f));
        descText.alignment = TextAlignmentOptions.Center;
 
        // ── 좌우 화살표 버튼 ──────────────────────────────────────
        int capturedIdx = deckSlotIndex;
 
        // 왼쪽 화살표
        GameObject leftBtn = CreateArrowButton(root, "◀",
            new Vector2(-W * 0.42f, -H * 0.35f),
            new Vector2(H * 0.1f, H * 0.1f), rarityColors[deckSlotIndex]);
        leftBtn.GetComponent<Button>().onClick.AddListener(() =>
        {
            slotSelection[capturedIdx] =
                (slotSelection[capturedIdx] - 1 + weaponDatabase.Count) % weaponDatabase.Count;
            RefreshDeckPanel(capturedIdx, nameText, typeText, statText, descText);
        });
 
        // 오른쪽 화살표
        GameObject rightBtn = CreateArrowButton(root, "▶",
            new Vector2(W * 0.42f, -H * 0.35f),
            new Vector2(H * 0.1f, H * 0.1f), rarityColors[deckSlotIndex]);
        rightBtn.GetComponent<Button>().onClick.AddListener(() =>
        {
            slotSelection[capturedIdx] =
                (slotSelection[capturedIdx] + 1) % weaponDatabase.Count;
            RefreshDeckPanel(capturedIdx, nameText, typeText, statText, descText);
        });
 
        // ── 장착 버튼 ─────────────────────────────────────────────
        GameObject equipBtn = new GameObject("EquipButton");
        equipBtn.transform.SetParent(root.transform, false);
        Image equipBG = equipBtn.AddComponent<Image>();
        equipBG.color = new Color(0.15f, 0.15f, 0.25f, 1f);
 
        RectTransform equipRT = equipBtn.GetComponent<RectTransform>();
        equipRT.anchoredPosition = new Vector2(0, -H * 0.35f);
        equipRT.sizeDelta        = new Vector2(W * 0.55f, H * 0.1f);
 
        TextMeshProUGUI equipText = CreateTMP(equipBtn, "EquipText",
            "EQUIP",
            Vector2.zero, new Vector2(W * 0.55f, H * 0.1f),
            18, FontStyles.Bold, rarityColors[deckSlotIndex]);
 
        Button equipBtnComp = equipBtn.AddComponent<Button>();
        equipBtnComp.targetGraphic = equipBG;
 
        ColorBlock ecb = equipBtnComp.colors;
        ecb.normalColor      = new Color(0.15f, 0.15f, 0.25f);
        ecb.highlightedColor = rarityColors[deckSlotIndex] * 0.5f;
        ecb.pressedColor     = rarityColors[deckSlotIndex] * 0.3f;
        equipBtnComp.colors  = ecb;
 
        equipBtnComp.onClick.AddListener(() =>
        {
            Weapon selected = weaponDatabase[slotSelection[capturedIdx]];
            if (selected == null) return;
 
            var deckMgr = WeaponDeck.Instance;
            if (deckMgr == null) return;
 
            // 보유 목록에 없으면 추가
            if (!deckMgr.ownedWeapons.Contains(selected))
                deckMgr.AddWeapon(selected);
 
            // 해당 슬롯에 장착
            deckMgr.EquipToSlot(selected, capturedIdx);
 
            // 버튼 피드백
            StartCoroutine(EquipFeedback(equipBG, equipText,
                                         rarityColors[capturedIdx]));
        });
 
        // 패널 참조 저장
        deckPanels[deckSlotIndex] = new DeckSlotPanel
        {
            nameText = nameText,
            typeText = typeText,
            statText = statText,
            descText = descText,
        };
    }
 
    IEnumerator EquipFeedback(Image bg, TextMeshProUGUI txt, Color rarityCol)
    {
        txt.text  = "EQUIPPED!";
        bg.color  = rarityCol * 0.6f;
        yield return new WaitForSeconds(1.2f);
        txt.text  = "EQUIP";
        bg.color  = new Color(0.15f, 0.15f, 0.25f);
    }
 
    void RefreshDeckPanel(int idx,
        TextMeshProUGUI nameT, TextMeshProUGUI typeT,
        TextMeshProUGUI statT, TextMeshProUGUI descT)
    {
        nameT.text = GetWeaponName(idx);
        typeT.text = GetWeaponType(idx);
        statT.text = GetWeaponStats(idx);
        descT.text = GetWeaponDesc(idx);
    }
 
    // ── 무기 정보 헬퍼 ────────────────────────────────────────────
 
    Weapon SelectedWeapon(int slotIdx)
    {
        int i = slotSelection[slotIdx];
        return (i < weaponDatabase.Count) ? weaponDatabase[i] : null;
    }
 
    string GetWeaponName(int slotIdx)
    {
        Weapon w = SelectedWeapon(slotIdx);
        return w != null ? w.weaponName.ToUpper() : "── EMPTY ──";
    }
 
    string GetWeaponType(int slotIdx)
    {
        Weapon w = SelectedWeapon(slotIdx);
        if (w == null) return "";
        return $"{w.type}  ·  {w.fireMode}  ·  {w.rarity}";
    }
 
    string GetWeaponStats(int slotIdx)
    {
        Weapon w = SelectedWeapon(slotIdx);
        if (w == null) return "";
        return $"DMG  {w.damage:F0}    SPD  {w.bulletSpeed:F0}\n" +
               $"MAG  {w.magazineSize}    RLD  {w.reloadTime:F1}s\n" +
               $"SPREAD  {w.spreadAngle:F0}°   x{w.bulletsPerShot}";
    }
 
    string GetWeaponDesc(int slotIdx)
    {
        Weapon w = SelectedWeapon(slotIdx);
        if (w == null) return "무기를 선택하세요";
        return string.IsNullOrEmpty(w.description) ? $"{w.weaponName}" : w.description;
    }
 
    // ── UI 생성 헬퍼 ──────────────────────────────────────────────
 
    static Image CreateImage(GameObject parent, string name, Rect rect, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        Image img = go.AddComponent<Image>();
        img.color = color;
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.sizeDelta        = new Vector2(rect.width, rect.height);
        rt.anchoredPosition = Vector2.zero;
        return img;
    }
 
    static TextMeshProUGUI CreateTMP(GameObject parent, string name,
        string text, Vector2 pos, Vector2 size,
        float fontSize, FontStyles style, Color color)
    {
        GameObject go = new GameObject(name);
        go.transform.SetParent(parent.transform, false);
        TextMeshProUGUI tmp = go.AddComponent<TextMeshProUGUI>();
        tmp.text      = text;
        tmp.fontSize  = fontSize;
        tmp.fontStyle = style;
        tmp.color     = color;
        tmp.alignment = TextAlignmentOptions.Center;
        tmp.enableWordWrapping = true;
 
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta        = size;
        return tmp;
    }
 
    static void CreateBorder(GameObject parent, float W, float H,
                              Color color, float thickness)
    {
        // 4개의 얇은 Image로 테두리 구성
        var borders = new (string n, Vector2 pos, Vector2 size)[]
        {
            ("Top",    new Vector2(0,    H*0.5f - thickness*0.5f), new Vector2(W, thickness)),
            ("Bottom", new Vector2(0,   -H*0.5f + thickness*0.5f), new Vector2(W, thickness)),
            ("Left",   new Vector2(-W*0.5f + thickness*0.5f, 0),   new Vector2(thickness, H)),
            ("Right",  new Vector2( W*0.5f - thickness*0.5f, 0),   new Vector2(thickness, H)),
        };
        foreach (var (n, pos, size) in borders)
        {
            var img = CreateImage(parent, $"Border_{n}",
                                   new Rect(pos.x, pos.y, size.x, size.y), color);
            img.GetComponent<RectTransform>().anchoredPosition = pos;
            img.GetComponent<RectTransform>().sizeDelta        = size;
        }
    }
 
    static GameObject CreateArrowButton(GameObject parent, string arrow,
        Vector2 pos, Vector2 size, Color color)
    {
        GameObject go = new GameObject($"Arrow_{arrow}");
        go.transform.SetParent(parent.transform, false);
 
        Image bg = go.AddComponent<Image>();
        bg.color = new Color(0.1f, 0.1f, 0.18f, 0.9f);
 
        RectTransform rt = go.GetComponent<RectTransform>();
        rt.anchoredPosition = pos;
        rt.sizeDelta        = size;
 
        TextMeshProUGUI txt = new GameObject("Txt").AddComponent<TextMeshProUGUI>();
        txt.transform.SetParent(go.transform, false);
        txt.text      = arrow;
        txt.fontSize  = size.y * 0.5f;
        txt.color     = color;
        txt.alignment = TextAlignmentOptions.Center;
        txt.GetComponent<RectTransform>().sizeDelta = size;
 
        Button btn = go.AddComponent<Button>();
        btn.targetGraphic = bg;
        ColorBlock cb = btn.colors;
        cb.highlightedColor = color * 0.4f;
        cb.pressedColor     = color * 0.2f;
        btn.colors = cb;
 
        return go;
    }
 
    // ── 내부 구조체 ───────────────────────────────────────────────
 
    class DeckSlotPanel
    {
        public TextMeshProUGUI nameText, typeText, statText, descText;
    }
}