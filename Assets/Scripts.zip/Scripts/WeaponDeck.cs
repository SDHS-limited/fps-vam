using System.Collections.Generic;
using UnityEngine;
 
/// <summary>
/// 덱 관리자 (싱글턴)
/// - 보유 무기 목록 관리
/// - 장착 슬롯 (최대 4개) 관리
/// - 게임 시작 시 권총 1자루 자동 지급
/// </summary>
public class WeaponDeck : MonoBehaviour
{
    public static WeaponDeck Instance { get; private set; }
 
    [Header("시작 무기")]
    public Weapon startingWeapon;           // Inspector에서 Pistol 에셋 연결
 
    [Header("덱 설정")]
    public int maxEquipSlots = 4;           // 동시 장착 최대 수
 
    // 전체 보유 목록
    public List<Weapon> ownedWeapons  { get; private set; } = new();
 
    // 장착 슬롯 (최대 4)
    public List<Weapon> equippedSlots { get; private set; } = new();
 
    // 현재 들고 있는 슬롯 인덱스
    public int activeSlotIndex { get; private set; } = 0;
 
    public Weapon ActiveWeapon => equippedSlots.Count > 0
                                    ? equippedSlots[activeSlotIndex]
                                    : null;
 
    // 이벤트
    public System.Action<Weapon> onWeaponAdded;
    public System.Action<int>    onSlotChanged;
    public System.Action         onDeckChanged;
 
    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
    }
 
    void Start()
    {
        // 게임 시작 → 권총 지급
        if (startingWeapon != null)
            AddWeapon(startingWeapon);
    }
 
    // ── 덱 조작 ───────────────────────────────────────────────────
 
    /// <summary>무기를 보유 목록에 추가하고 빈 슬롯이 있으면 자동 장착</summary>
    public bool AddWeapon(Weapon weapon)
    {
        if (weapon == null) return false;
 
        ownedWeapons.Add(weapon);
        onWeaponAdded?.Invoke(weapon);
 
        // 빈 슬롯 있으면 자동 장착
        if (equippedSlots.Count < maxEquipSlots)
        {
            equippedSlots.Add(weapon);
            onDeckChanged?.Invoke();
        }
 
        return true;
    }
 
    /// <summary>특정 슬롯에 무기 교체</summary>
    public void EquipToSlot(Weapon weapon, int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= maxEquipSlots) return;
        if (!ownedWeapons.Contains(weapon)) return;
 
        if (slotIndex < equippedSlots.Count)
            equippedSlots[slotIndex] = weapon;
        else
        {
            // 슬롯이 아직 없으면 순서대로 채움
            while (equippedSlots.Count <= slotIndex)
                equippedSlots.Add(null);
            equippedSlots[slotIndex] = weapon;
        }
 
        onDeckChanged?.Invoke();
    }
 
    /// <summary>슬롯 비우기</summary>
    public void UnequipSlot(int slotIndex)
    {
        if (slotIndex < 0 || slotIndex >= equippedSlots.Count) return;
        equippedSlots.RemoveAt(slotIndex);
 
        // 활성 슬롯 범위 유지
        activeSlotIndex = Mathf.Clamp(activeSlotIndex, 0,
                                       Mathf.Max(0, equippedSlots.Count - 1));
        onDeckChanged?.Invoke();
    }
 
    /// <summary>활성 슬롯 변경 (숫자키 / 스크롤)</summary>
    public void SetActiveSlot(int index)
    {
        if (equippedSlots.Count == 0) return;
        activeSlotIndex = Mathf.Clamp(index, 0, equippedSlots.Count - 1);
        onSlotChanged?.Invoke(activeSlotIndex);
    }
 
    public void NextSlot() => SetActiveSlot((activeSlotIndex + 1) % equippedSlots.Count);
    public void PrevSlot() => SetActiveSlot((activeSlotIndex - 1 + equippedSlots.Count)
                                             % equippedSlots.Count);
}
 