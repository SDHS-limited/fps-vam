using System.Collections;
using UnityEngine;
 
/// <summary>
/// 실제 발사 / 재장전 로직
/// WeaponController와 분리되어 순수 발사 처리만 담당
/// Player의 자식 오브젝트 "GunPivot"에 부착 권장
/// </summary>
public class ShootingSystem : MonoBehaviour
{
    [Header("레퍼런스")]
    public Transform   muzzle;              // 총구 위치 Transform
    public GameObject  bulletPrefab;        // Bullet.cs 부착된 프리팹
    public Transform   cameraTransform;     // FPS 카메라
 
    [Header("이펙트")]
    public ParticleSystem muzzleFlash;
    public AudioSource    audioSource;
    public AudioClip      defaultFireSFX;
    public AudioClip      defaultReloadSFX;
 
    // ── 상태 ──────────────────────────────────────────────────────
 
    Weapon currentWeapon;
 
    int   currentAmmo   = 0;
    bool  isReloading   = false;
    float fireCooldown  = 0f;
    int   burstCount    = 0;        // 점사 카운터
 
    // 반동 상태
    float recoilPitch   = 0f;
    float recoilYaw     = 0f;
 
    // 이벤트
    public System.Action<int, int> onAmmoChanged;   // (현재, 최대)
    public System.Action           onReloadStart;
    public System.Action           onReloadEnd;
 
    // ── 외부 API ──────────────────────────────────────────────────
 
    /// <summary>무기 교체 시 WeaponController가 호출</summary>
    public void EquipWeapon(Weapon weapon)
    {
        StopAllCoroutines();
        isReloading   = false;
        fireCooldown  = 0f;
        currentWeapon = weapon;
 
        if (weapon != null)
        {
            currentAmmo = weapon.magazineSize;
            onAmmoChanged?.Invoke(currentAmmo, weapon.magazineSize);
        }
    }
 
    /// <summary>발사 시도. Update에서 입력에 따라 호출</summary>
    public void TryFire()
    {
        if (currentWeapon == null || isReloading) return;
        if (fireCooldown > 0f) return;
 
        if (currentAmmo <= 0)
        {
            // 탄창 비면 자동 재장전 시도
            TryReload();
            return;
        }
 
        switch (currentWeapon.fireMode)
        {
            case FireMode.SemiAuto:
                Fire();
                break;
 
            case FireMode.FullAuto:
                Fire();
                break;
 
            case FireMode.Burst:
                if (burstCount == 0)
                    StartCoroutine(BurstFire());
                break;
        }
    }
 
    /// <summary>재장전 시도</summary>
    public void TryReload()
    {
        if (currentWeapon == null) return;
        if (isReloading) return;
        if (currentAmmo >= currentWeapon.magazineSize) return;
 
        StartCoroutine(Reload());
    }
 
    // ── 발사 내부 ─────────────────────────────────────────────────
 
    void Fire()
    {
        fireCooldown = currentWeapon.fireRate;
 
        if (!currentWeapon.infiniteAmmo)
        {
            currentAmmo--;
            onAmmoChanged?.Invoke(currentAmmo, currentWeapon.magazineSize);
        }
 
        // 산탄 수만큼 총알 생성
        for (int i = 0; i < currentWeapon.bulletsPerShot; i++)
            SpawnBullet();
 
        // 이펙트
        PlayMuzzleFlash();
        PlayFireSFX();
 
        // 반동
        ApplyRecoil();
    }
 
    void SpawnBullet()
    {
        if (bulletPrefab == null || muzzle == null) return;
 
        // 발사 방향: 카메라 정면 + 퍼짐
        Vector3 dir = cameraTransform
                      ? cameraTransform.forward
                      : muzzle.forward;
 
        // 퍼짐 적용
        if (currentWeapon.spreadAngle > 0f)
        {
            float half = currentWeapon.spreadAngle * 0.5f;
            dir = Quaternion.Euler(
                Random.Range(-half, half),
                Random.Range(-half, half),
                0f) * dir;
        }
 
        // 총알 스폰
        GameObject go = Instantiate(bulletPrefab, muzzle.position, Quaternion.LookRotation(dir));
        var bullet = go.GetComponent<Bullet>();
        bullet?.Init(dir,
                     currentWeapon.damage,
                     currentWeapon.bulletSpeed,
                     currentWeapon.bulletRange,
                     currentWeapon.knockback);
    }
 
    IEnumerator BurstFire()
    {
        burstCount = 3;
        while (burstCount > 0 && currentAmmo > 0)
        {
            Fire();
            burstCount--;
            yield return new WaitForSeconds(currentWeapon.fireRate * 0.4f);
        }
        burstCount = 0;
        // 점사 후 추가 쿨다운
        fireCooldown = currentWeapon.fireRate;
    }
 
    IEnumerator Reload()
    {
        isReloading = true;
        onReloadStart?.Invoke();
        PlayReloadSFX();
 
        yield return new WaitForSeconds(currentWeapon.reloadTime);
 
        currentAmmo = currentWeapon.magazineSize;
        isReloading = false;
        onReloadEnd?.Invoke();
        onAmmoChanged?.Invoke(currentAmmo, currentWeapon.magazineSize);
    }
 
    // ── 반동 ──────────────────────────────────────────────────────
 
    void ApplyRecoil()
    {
        recoilPitch += currentWeapon.recoilUp;
        recoilYaw   += Random.Range(-currentWeapon.recoilSide,
                                     currentWeapon.recoilSide);
    }
 
    /// <summary>WeaponController가 LateUpdate에서 카메라에 반동 적용시 호출</summary>
    public Vector2 ConsumeRecoil(float recoverSpeed)
    {
        Vector2 r = new Vector2(recoilPitch, recoilYaw);
        recoilPitch = Mathf.Lerp(recoilPitch, 0f, Time.deltaTime * recoverSpeed);
        recoilYaw   = Mathf.Lerp(recoilYaw,   0f, Time.deltaTime * recoverSpeed);
        return r;
    }
 
    // ── 이펙트 헬퍼 ───────────────────────────────────────────────
 
    void PlayMuzzleFlash()
    {
        if (muzzleFlash != null)
            muzzleFlash.Play();
    }
 
    void PlayFireSFX()
    {
        if (audioSource != null && defaultFireSFX != null)
            audioSource.PlayOneShot(defaultFireSFX);
    }
 
    void PlayReloadSFX()
    {
        if (audioSource != null && defaultReloadSFX != null)
            audioSource.PlayOneShot(defaultReloadSFX);
    }
 
    // ── Update ────────────────────────────────────────────────────
 
    void Update()
    {
        if (fireCooldown > 0f)
            fireCooldown -= Time.deltaTime;
    }
 
    // ── 상태 프로퍼티 (HUD용) ─────────────────────────────────────
 
    public int   CurrentAmmo    => currentAmmo;
    public int   MaxAmmo        => currentWeapon != null ? currentWeapon.magazineSize : 0;
    public bool  IsReloading    => isReloading;
    public float ReloadProgress => isReloading && currentWeapon != null
                                    ? 1f - (fireCooldown / currentWeapon.reloadTime)
                                    : 1f;
}
 